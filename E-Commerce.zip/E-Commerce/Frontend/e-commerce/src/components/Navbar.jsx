import React, { useContext } from 'react'
import { json } from 'react-router-dom'
import { NavLink } from 'react-router-dom'
import AppContext from '../context/AppContext'

const Navbar = () => {
  const {cart}=useContext(AppContext)
  console.log(cart?.length,"cart length")
  return (
    <>
<nav>
  <ul>
    <li>
      <NavLink exact to="/">Home</NavLink>
    </li>
    <li>
      <NavLink to="/addproduct">Add Product</NavLink>
    </li>
    <li>
      <NavLink to="/addcategory">Add Category</NavLink>
    </li>
    <li className='right'>
      <NavLink  to="/cart">Cart {cart?.length}</NavLink>
    </li>
  </ul>
</nav>


</>
  )
}

export default Navbar
