import React, { createContext, useState } from 'react'

export  const AppContext =createContext()
export const AppContextProvider = ({children}) => {

      //states
      const [cart, setCart] = useState([]);

      //function for fetcing data from server apis
      const getData = async () => {
        try {
          const res = await fetch("http://localhost:8080/Carts/allCarts");
          const data = await res.json();
          console.log(data);
          setCart(data);
        } catch (error) {
          console.log(error);
        }
      };

  return (
    <AppContext.Provider value={{cart,getData}} >
      {children}
    </AppContext.Provider>
  )
}

export default AppContext;