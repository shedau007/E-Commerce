import React, { useEffect, useState } from 'react'
import {
    Flex,
    Box,
    FormControl,
    FormLabel,
    Input,
    Checkbox,
    Stack,
    Link,
    Button,
    Heading,
    Text,
    useColorModeValue,
    Select,
    useToast,
  } from '@chakra-ui/react';
  import { GrAdd } from 'react-icons/gr';

const initialState={
    categoryName:""
}
const Addcategory = () => {
const [formData,setformData]=useState(initialState)


const toast = useToast()
  //for adding items in cart 
  const handleAddCategory=async()=>{
    try {
      const response = await fetch("http://localhost:8080/Categories", {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      });
      const responseData = await response.json();
      console.log(responseData);
      toast({
        title: 'Category Added Successfully',
        
        status: 'success',
        duration: 3000,
        isClosable: true,
        position:"top"
      })
      setformData(initialState);
    } catch (error) {
      console.error(error);
    }
    
  }


const handleAddproduct=(e)=>{
    setformData((prev)=>{
       return {
      ...prev,
           [e.target.name]:e.target.value
       }
        
    })
}


  return (
    <Flex
    minH={'100vh'}
    align={'center'}
    justify={'center'}
    bg={useColorModeValue('gray.50', 'gray.800')}>
    <Stack spacing={8} mx={'auto'} maxW={'xxl'} py={20} px={20}>
      <Stack align={'center'}>
        
        <Text fontSize={'2xl'} fontWeight={'semibold'}  color={'gray.800'}>
          Add Category  ✌️
        </Text>
      </Stack>
      <Box
        rounded={'lg'}
        bg={useColorModeValue('white', 'gray.700')}
        boxShadow={'lg'}
        p={8} width={600}>
        <Stack spacing={4}>
          <FormControl id="email">
            <FormLabel>Title</FormLabel>
            <Input name='categoryName' onChange={handleAddproduct} value={formData.categoryName} type="text" />
          </FormControl>
          <Stack spacing={10}>
           
            <Button onClick={handleAddCategory}
              colorScheme='red'
              _hover={{
                bg: 'red.500',
              }}>
            <Box ><GrAdd  style={{color:"white",marginRight:"5px"}} /></Box>  Add Category
            </Button>
          </Stack>
        </Stack>
      </Box>
    </Stack>
  </Flex>
  )
}

export default Addcategory
