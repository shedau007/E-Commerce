import React, { useContext, useEffect, useState } from "react";
import { Box, HStack, Image, SimpleGrid, Text, Button, Spacer, CircularProgress, VStack, Input, Select, Stack, useToast } from '@chakra-ui/react'
import { HiOutlineShoppingBag } from 'react-icons/hi';
import AppContext from "../context/AppContext";

const Home = () => {
  const {cart,getData}=useContext(AppContext)
  //states
  const [data, setData] = useState([]);
  const [renderedData, setRenderedData] = useState([]);
  const [search,setSearch]=useState("")

  //function for fetcing data from server apis
  const fetchData = async () => {
    try {
      const res = await fetch("http://localhost:8080/products/allProducts");
      const data = await res.json();
      console.log(data);
      setData(data);
      setRenderedData(data)
    } catch (error) {
      console.log(error);
    }
  };
  function handleSortChange(sortOption) {
    const sortedData = [...renderedData].sort((a, b) => {
      if (sortOption === "High To Low") {
        return b.price - a.price;
      } else if (sortOption === "Low To High") {
        return a.price - b.price;
      }
   
    });
    // do something with the sortedData
    // console.log(sortedData);
    setRenderedData(sortedData)
  }
  

  //for rendering data
  useEffect(() => {
    fetchData();
    getData()
  }, []);

const toast=useToast()

  //for adding items in cart 
  const addToCart=async(el)=>{
    try {
      const response = await fetch("http://localhost:8080/Carts", {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(el)
      });
      const responseData = await response.json();
      console.log(responseData);
      toast({
        title: 'Product Added to Cart',
        
        status: 'success',
        duration: 3000,
        isClosable: true,
        position:"top"
      })
    } catch (error) {
      console.error(error);
    }
    
  }

  const [filter, setFilter] = useState("");

const handleFilterChange = (value) => {
  setFilter(value);
};

  const categories = [...new Set(data.map((item) => item.category))];

//for reducing the size of description and title
const shortString = (text, limit = 20) => {
  return text.slice(0, limit) + (text.length > limit ? "..." : "");
};

const shortStringdesc = (text, limit = 25) => {
  return text.slice(0, limit) + (text.length > limit ? "..." : "");
};
  return (
    <VStack >
    <HStack padding='10px 20px' justify='space-between' w='100%' >
      <Stack>

       <Select onChange={(e)=>handleSortChange(e.target.value)} placeholder="Sort By Price">
      
        <option>High To Low</option>
        <option>Low To High</option>
       </Select>
      </Stack>
   <Stack>

       <Select onChange={(e) => handleFilterChange(e.target.value)} placeholder="Filter By Categories">
  <option value="">All Categories</option>
  {categories?.map((category) => (
    <option key={category} value={category}>
      {category}
    </option>
  ))}
</Select>
  </Stack>

        <Text bgClip='text'
            bgGradient='linear(to-l, #7928CA, #FF0080)' color='pink.500' alignSelf='center' fontSize='2xl' as='b'>E-Commerce App</Text>
            <Input w='30%' type="text" value={search} onChange={(e)=>setSearch(e.target.value)}  placeholder="Search product by title" />
    </HStack>
    
    <SimpleGrid p={{base:0,sm:4}} w={{base:"100%",lg:"90%"}}   columns={{ base: 2,sm:3,md:4}}   spacing={{base:0,md:3,lg:5}}>
    {
       renderedData?.filter((el) => el.title.toLowerCase().includes(search.toLowerCase()))
       .filter((el) => !filter || el.category.toLowerCase() === filter.toLowerCase()).map((el,i) => {
                return (
        <Box cursor={'pointer'}  key={i} border='1px solid #eeee'  >
            <Box px='2' borderRadius={2} >
                <Image borderRadius={5} py={1} width='100%' h={'190px'} src={el.imageUrl} /></Box>
            <Box px='2' >
                <Text as='b' fontSize={{base:"15px",lg:'lg'}}>{shortString(el.title)}</Text>
                <Text pt={2} fontSize={{base:"14px",lg:'md'}} color='gray.500'>{shortStringdesc(el.description)}</Text>
               
                <Text fontSize={{base:"14px",lg:'lg'}} pt={1} pb='2' color='gray.500'> <span style={{ color: "red" }}>★</span>   reviews</Text>
                <Text py={2} fontWeight='medium'>₹ {el.price}</Text>
            </Box>
            <Spacer/>
            <Box zIndex={9999} py={3} px='2' display='flex' w={'full'}  >

            <Button onClick={()=>{addToCart(el); getData()}} colorScheme="facebook" fontWeight='medium' size={{ base: "xs", sm: "sm" }}  ><HiOutlineShoppingBag fontSize={'1.3rem'} style={{ marginRight: "5px" }} /> Add To Cart</Button> 
            </Box>
        </Box>
        )
            })
        }

      
    </SimpleGrid>

  

</VStack>
  );
};

export default Home;
