import React, { useEffect, useState } from 'react'
import {
    Flex,
    Box,
    FormControl,
    FormLabel,
    Input,
    Checkbox,
    Stack,
    Link,
    Button,
    Heading,
    Text,
    useColorModeValue,
    Select,
    useToast,
  } from '@chakra-ui/react';
  import { GrAdd } from 'react-icons/gr';
const initialState={
    title:"",
    imageUrl:"",
    description:"",
    price:0,
    category:""
}
const Addproduct = () => {
const [formData,setformData]=useState(initialState)
     //states
     const [category_list, setcategory_list] = useState([]);

     //function for fetcing data from server apis
     const getData = async () => {
       try {
         const res = await fetch("http://localhost:8080/Categories/allCategory");
         const data = await res.json();
         console.log(data);
         setcategory_list(data);
       } catch (error) {
         console.log(error);
       }
     };
console.log(formData,"formdata")

useEffect(()=>{
    getData()
}
,[])
const toast = useToast()
  //for adding items in cart 
  const handleAddProducts=async()=>{
    try {
      const response = await fetch("http://localhost:8080/products", {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      });
      const responseData = await response.json();
      console.log(responseData);
      toast({
        title: 'Product Added Successfully',
        
        status: 'success',
        duration: 3000,
        isClosable: true,
        position:"top"
      })
      setformData(initialState);
    } catch (error) {
      console.error(error);
    }
    
  }


const handleAddproduct=(e)=>{
    setformData((prev)=>{
       return {
      ...prev,
           [e.target.name]:e.target.value
       }
        
    })
}


  return (
    <Flex
    minH={'100vh'}
    align={'center'}
    justify={'center'}
    bg={useColorModeValue('gray.50', 'gray.800')}>
    <Stack spacing={8} mx={'auto'} maxW={'xxl'} py={20} px={20}>
      <Stack align={'center'}>
        
        <Text fontSize={'2xl'} fontWeight={'semibold'}  color={'gray.800'}>
          Add Product  ✌️
        </Text>
      </Stack>
      <Box
        rounded={'lg'}
        bg={useColorModeValue('white', 'gray.700')}
        boxShadow={'lg'}
        p={8} width={600}>
        <Stack spacing={4}>
          <FormControl id="email">
            <FormLabel>Title</FormLabel>
            <Input name='title' onChange={handleAddproduct} value={formData.title} type="text" />
          </FormControl>
          <FormControl id="text">
            <FormLabel>Description</FormLabel>
            <Input name='description'  onChange={handleAddproduct} value={formData.description} type="text" />
          </FormControl>
          <FormControl id="password">
            <FormLabel>ImageURl</FormLabel>
            <Input name='imageUrl' onChange={handleAddproduct} value={formData.imageUrl}  type="text" />
          </FormControl>
          <FormControl id="password">
            <FormLabel>Price</FormLabel>
            <Input name='price' onChange={handleAddproduct} value={formData.price}  type="number" />
          </FormControl>
          <FormControl id="password">
            <FormLabel>Category</FormLabel>
            <Select name='category' onChange={handleAddproduct} value={formData.category}>
  {category_list?.map((option) => (
    <option key={option.categoryName} value={option.categoryName}>{option.categoryName}</option>
  ))}
</Select>

          </FormControl>
          <Stack spacing={10}>
           
            <Button onClick={handleAddProducts}
              colorScheme='red'
              _hover={{
                bg: 'red.500',
              }}>
            <Box ><GrAdd  style={{color:"white",marginRight:"5px"}} /></Box>  Add Product
            </Button>
          </Stack>
        </Stack>
      </Box>
    </Stack>
  </Flex>
  )
}

export default Addproduct
