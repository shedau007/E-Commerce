import React from 'react'
import { Route, Routes } from 'react-router-dom'
import Home from '../pages/Home'
import Cart from '../pages/Cart'
import Addproduct from '../pages/Addproduct'
import Addcategory from '../pages/Addcategory'

const AllRoutes = () => {
  return (
    <Routes>
        <Route path='/' element={<Home/>} />
        <Route path='/cart' element={<Cart/>} />
        <Route path='/addproduct' element={<Addproduct/>} />
        <Route path='/addcategory' element={<Addcategory/>} />
    </Routes>
  )
}

export default AllRoutes
